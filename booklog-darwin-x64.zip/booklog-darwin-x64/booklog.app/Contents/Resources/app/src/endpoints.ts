const EventEndpoint = 'https://booklog-9c5b1.firebaseio.com/events.json';
const ClubEndpoint = 'https://booklog-9c5b1.firebaseio.com/clubs';

export {
    EventEndpoint,
    ClubEndpoint
};
