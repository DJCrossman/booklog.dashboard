# booklog.dashboard
A dashboard for booklog to track and add events
